# PESU — Fresh Mobile App

Fresh Flutter starter for an Android-first Tamil Super Messenger.

Included:
- Mobile-first responsive UI
- AMOLED dark theme
- Chats, Calls, Communities, Status
- Search UI
- New Chat bottom sheet
- Tamil-first PESU branding
- Material 3 navigation

Run:
1. Install Flutter + Android Studio.
2. `flutter pub get`
3. `flutter run`

Release APK:
`flutter build apk --release`


## Build APK with GitHub Actions

1. Upload all files in this project to a GitHub repository.
2. Open the repository's **Actions** tab.
3. Select **Build PESU APK**.
4. Choose **Run workflow**.
5. When the workflow finishes, open the successful run.
6. Download the **PESU-APK** artifact.

No Android Studio is required on your phone for the GitHub build.
