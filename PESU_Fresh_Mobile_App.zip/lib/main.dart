import 'package:flutter/material.dart';

void main() => runApp(const PesuApp());

class PesuApp extends StatelessWidget {
  const PesuApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'PESU',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF07090D),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFFF5A36),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const MainScreen(),
    );
  }
}

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});
  @override State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int tab = 0;
  final screens = const [Chats(), Calls(), Communities(), Status()];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: screens[tab]),
      floatingActionButton: tab == 0
          ? FloatingActionButton(
              onPressed: () => showModalBottomSheet(
                context: context,
                showDragHandle: true,
                builder: (_) => const SafeArea(
                  child: Padding(
                    padding: EdgeInsets.all(20),
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      ListTile(leading: Icon(Icons.person_add), title: Text('New contact')),
                      ListTile(leading: Icon(Icons.group_add), title: Text('New group')),
                      ListTile(leading: Icon(Icons.qr_code), title: Text('Scan PESU ID')),
                    ]),
                  ),
                ),
              ),
              child: const Icon(Icons.edit_rounded),
            )
          : null,
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline), selectedIcon: Icon(Icons.chat_bubble), label: 'Chats'),
          NavigationDestination(icon: Icon(Icons.call_outlined), selectedIcon: Icon(Icons.call), label: 'Calls'),
          NavigationDestination(icon: Icon(Icons.groups_outlined), selectedIcon: Icon(Icons.groups), label: 'Communities'),
          NavigationDestination(icon: Icon(Icons.auto_awesome_outlined), selectedIcon: Icon(Icons.auto_awesome), label: 'Status'),
        ],
      ),
    );
  }
}

class Chats extends StatelessWidget {
  const Chats({super.key});
  @override
  Widget build(BuildContext context) {
    final data = [
      ('Arun', 'Enna da, nalaiku varuviya?', '10:42 PM', Icons.person),
      ('College Group', 'Priya: Meeting 9 AM 👍', '9:18 PM', Icons.groups),
      ('Gaming Squad', '🔥 Match tonight!', '8:56 PM', Icons.sports_esports),
      ('Amma', 'Saptiya?', 'Yesterday', Icons.favorite),
    ];
    return CustomScrollView(slivers: [
      SliverAppBar(
        pinned: true,
        title: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('PESU', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 2)),
          Text('பேசு • Connect • Share • Feel', style: TextStyle(fontSize: 11, color: Colors.white54)),
        ]),
        actions: [
          IconButton(onPressed: () {}, icon: const Icon(Icons.search)),
          IconButton(onPressed: () {}, icon: const Icon(Icons.more_vert)),
        ],
      ),
      SliverToBoxAdapter(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 12),
          child: TextField(
            decoration: InputDecoration(
              hintText: 'Search messages, people & media',
              prefixIcon: const Icon(Icons.search),
              filled: true, fillColor: const Color(0xFF12161D),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
            ),
          ),
        ),
      ),
      SliverList.builder(
        itemCount: data.length,
        itemBuilder: (_, i) => ListTile(
          contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 5),
          leading: CircleAvatar(radius: 27, child: Icon(data[i].$4)),
          title: Text(data[i].$1, style: const TextStyle(fontWeight: FontWeight.w700)),
          subtitle: Text(data[i].$2, maxLines: 1, overflow: TextOverflow.ellipsis),
          trailing: Text(data[i].$3, style: const TextStyle(fontSize: 11, color: Colors.white54)),
        ),
      ),
    ]);
  }
}

class Calls extends StatelessWidget {
  const Calls({super.key});
  @override Widget build(BuildContext c) => const Center(child: Text('📞\nCalls\n\nHD voice & video\nWebRTC ready', textAlign: TextAlign.center, style: TextStyle(fontSize: 22)));
}
class Communities extends StatelessWidget {
  const Communities({super.key});
  @override Widget build(BuildContext c) => const Center(child: Text('👥\nCommunities\n\nFriends • College • Gaming • Family', textAlign: TextAlign.center, style: TextStyle(fontSize: 21)));
}
class Status extends StatelessWidget {
  const Status({super.key});
  @override Widget build(BuildContext c) => const Center(child: Text('✨\nStatus\n\nShare moments with your people', textAlign: TextAlign.center, style: TextStyle(fontSize: 22)));
}
